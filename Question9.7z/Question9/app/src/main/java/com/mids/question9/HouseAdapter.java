package com.mids.question9;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
public class HouseAdapter extends RecyclerView.Adapter<HouseAdapter.ViewHolder> {
    private Context context;
    private List<House> houses;
    private LayoutInflater layoutInflater;
    public HouseAdapter(Context context, List<House> houses) {
        this.context = context;
        this.houses = houses;
        this.layoutInflater = LayoutInflater.from(context);
    }
    @NonNull
    @Override
    public HouseAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(layoutInflater.inflate(R.layout.items, parent, false));
    }
    @Override
    public void onBindViewHolder(@NonNull HouseAdapter.ViewHolder holder, int position) {
        holder.txt_price.setText(houses.get(position).getPrice());
        holder.txt_place.setText(houses.get(position).getPlace());
        holder.txt_city.setText(houses.get(position).getCity());
        holder.txt_category.setText(houses.get(position).getCategory());
        holder.txt_area.setText(houses.get(position).getArea());
    }
    @Override
    public int getItemCount() { return houses == null ? 0 : houses.size();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView txt_place, txt_price, txt_city, txt_category, txt_area;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txt_price = itemView.findViewById(R.id.txt_price);
            txt_price = itemView.findViewById(R.id.txt_place);
            txt_city = itemView.findViewById(R.id.txt_city);
            txt_category = itemView.findViewById(R.id.txt_category);
            txt_area = itemView.findViewById(R.id.txt_area);
        }
    }
}

